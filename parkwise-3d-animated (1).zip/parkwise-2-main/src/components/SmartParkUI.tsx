import { useState, type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { ArrowRight, Bell, Building2, CalendarDays, Car, Check, ChevronRight, CircleHelp, Clock3, Command, Compass, CreditCard, Gauge, History, LayoutDashboard, LogOut, MapPin, Menu, Navigation, ParkingSquare, Search, Settings, ShieldCheck, SlidersHorizontal, Sparkles, Star, UserRound, X, Zap } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { parkingLocations, type Booking, type ParkingLocation, type ParkingSlot, type SlotStatus } from '@/data/mock';

export function AppLogo({ dark = false }: { dark?: boolean }) {
  return <Link href="/" data-testid="link-logo" className="flex items-center gap-2.5">
    <span className={`grid h-9 w-9 place-items-center rounded-xl ${dark ? 'bg-white/10 text-[#f6bd60]' : 'bg-[#153b5b] text-[#f6bd60]'}`}><ParkingSquare size={19} strokeWidth={2.5} /></span>
    <span className={`font-display text-[17px] font-bold tracking-[-.04em] ${dark ? 'text-white' : 'text-[#183653]'}`}>park<span className="text-[#e9a84d]">wise</span></span>
  </Link>;
}

export function StatusBadge({ status, label }: { status: string; label?: string }) {
  const styles: Record<string, string> = {
    confirmed: 'bg-[#dcf4e9] text-[#18724b]', upcoming: 'bg-[#e8f1f7] text-[#255d78]', active: 'bg-[#dcf4e9] text-[#18724b]', completed: 'bg-[#eef0f3] text-[#5c6873]', cancelled: 'bg-[#fce9e8] text-[#ae4642]',
    available: 'bg-[#dcf4e9] text-[#18724b]', occupied: 'bg-[#fce9e8] text-[#ae4642]', reserved: 'bg-[#e8e9fb] text-[#5656a8]', maintenance: 'bg-[#fff0d5] text-[#95641c]', online: 'bg-[#dcf4e9] text-[#18724b]', offline: 'bg-[#fce9e8] text-[#ae4642]',
  };
  return <span data-testid={`status-${status}`} className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold capitalize ${styles[status.toLowerCase()] || 'bg-muted text-muted-foreground'}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{label || status}</span>;
}

export function PublicNav() {
  const { user, logout, unreadCount } = useApp();
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const links = [['/', 'Home'], ['/parking', 'Find parking'], ['/bookings', 'My bookings'], ['/history', 'History']];
  return <header className="sticky top-0 z-40 border-b border-[#dfe7ec]/80 bg-[#f5f8fa]/90 backdrop-blur-xl">
    <div className="mx-auto flex h-[70px] max-w-[1240px] items-center justify-between px-5 lg:px-8">
      <AppLogo />
      <nav className="hidden items-center gap-1 md:flex">{links.map(([href, label]) => <Link key={href} href={href} data-testid={`link-nav-${label.replace(' ', '-')}`} className={`rounded-lg px-3.5 py-2 text-[13px] font-semibold transition-colors hover:bg-white hover:text-[#153b5b] ${location === href ? 'text-[#153b5b]' : 'text-[#73818b]'}`}>{label}</Link>)}</nav>
      <div className="hidden items-center gap-2 md:flex">
        {user ? <>{user.role === 'admin' && <Link href="/admin/dashboard" data-testid="link-admin-portal" className="rounded-xl bg-[#f4c26f]/15 px-3 py-2 text-sm font-bold text-[#c28636] hover:bg-[#f4c26f]/25">Admin</Link>}<Link href="/notifications" data-testid="link-notifications" className="relative rounded-xl p-2.5 text-[#667985] hover:bg-white"><Bell size={18} />{unreadCount > 0 && <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-[#edac4e]" />}</Link><Link href={user.role === 'admin' ? '/admin/dashboard' : '/profile'} data-testid="link-profile" className="flex items-center gap-2 rounded-xl px-2 py-1.5 hover:bg-white"><span className="grid h-8 w-8 place-items-center rounded-full bg-[#d8e8ed] text-xs font-bold text-[#1d5b72]">{user.name.split(' ').map((n) => n[0]).join('')}</span><span className="max-w-28 truncate text-xs font-bold text-[#344e5f]">{user.name}</span></Link><button onClick={logout} data-testid="button-logout" className="rounded-xl p-2 text-[#81909a] hover:bg-white hover:text-[#af4a46]" aria-label="Log out"><LogOut size={16} /></button></> : <><Link href="/login" data-testid="link-login" className="px-3 py-2 text-sm font-bold text-[#345064]">Log in</Link><Link href="/register" data-testid="link-register" className="rounded-xl bg-[#153b5b] px-4 py-2.5 text-sm font-bold text-white shadow-sm transition-transform hover:-translate-y-0.5">Create account</Link></>}
      </div>
      <button onClick={() => setOpen(!open)} data-testid="button-mobile-menu" className="rounded-xl p-2 text-[#345064] md:hidden" aria-label="Open menu">{open ? <X size={20} /> : <Menu size={21} />}</button>
    </div>
    {open && <div className="border-t border-[#dfe7ec] bg-[#f5f8fa] px-5 py-4 md:hidden">{links.map(([href, label]) => <Link onClick={() => setOpen(false)} key={href} href={href} data-testid={`link-mobile-${label.replace(' ', '-')}`} className="block border-b border-[#dfe7ec] py-3 text-sm font-semibold text-[#345064]">{label}</Link>)}<Link href={user ? '/profile' : '/login'} onClick={() => setOpen(false)} data-testid="link-mobile-account" className="mt-3 block py-2 text-sm font-bold text-[#153b5b]">{user ? 'Your account' : 'Log in'}</Link><Link href="/admin/login" onClick={() => setOpen(false)} data-testid="link-mobile-admin" className="block py-2 text-sm font-bold text-[#c28636]">Admin portal</Link></div>}
  </header>;
}

export function UserShell({ children }: { children: ReactNode }) {
  return <div className="min-h-[100dvh] bg-[#f5f8fa]"><PublicNav />{children}<footer className="mt-20 border-t border-[#dfe7ec] bg-[#eef4f6]"><div className="mx-auto flex max-w-[1240px] flex-col gap-4 px-5 py-8 text-xs text-[#72828c] md:flex-row md:items-center md:justify-between lg:px-8"><AppLogo /><span>Quietly making arrival predictable.</span><span>Mock product experience · 2026</span></div></footer></div>;
}

const adminLinks = [['/admin/dashboard', 'Overview', LayoutDashboard], ['/admin/locations', 'Locations', Building2], ['/admin/slots', 'Slot operations', ParkingSquare], ['/admin/reservations', 'Reservations', CalendarDays], ['/admin/users', 'Users', UserRound], ['/admin/devices', 'IoT devices', Zap], ['/admin/ai', 'AI monitoring', Sparkles], ['/admin/analytics', 'Analytics', Gauge], ['/admin/settings', 'Settings', Settings]] as const;

export function AdminShell({ children }: { children: ReactNode }) {
  const [location, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const { user, logout } = useApp();
  return <div className="min-h-[100dvh] bg-[#f5f7f8]">
    <aside className={`fixed inset-y-0 left-0 z-50 w-[245px] bg-[#122f49] px-4 py-5 text-white transition-transform md:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="mb-9 flex items-center justify-between px-2"><AppLogo dark /><button onClick={() => setOpen(false)} className="rounded-lg p-1 text-white/70 md:hidden" aria-label="Close navigation"><X size={18} /></button></div>
      <p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[.17em] text-white/40">Command center</p>
      <nav className="space-y-1">{adminLinks.map(([href, label, Icon]) => <button key={href} onClick={() => { setLocation(href); setOpen(false); }} data-testid={`link-admin-${label.toLowerCase().replaceAll(' ', '-')}`} className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[13px] font-semibold transition-colors ${location === href ? 'bg-white/12 text-[#f6bd60]' : 'text-white/65 hover:bg-white/7 hover:text-white'}`}><Icon size={17} strokeWidth={1.8} />{label}</button>)}</nav>
      <div className="absolute bottom-5 left-4 right-4 rounded-2xl border border-white/10 bg-white/5 p-3"><div className="flex items-center gap-2"><span className="grid h-8 w-8 place-items-center rounded-full bg-[#e8ad50] text-xs font-black text-[#34220c]">{(user?.name || 'Admin').split(' ').map((n) => n[0]).join('').slice(0, 2)}</span><div className="min-w-0"><p className="truncate text-xs font-bold">{user?.name || 'Admin'}</p><p className="text-[10px] text-white/45">System operator</p></div><button onClick={logout} className="ml-auto text-white/45 hover:text-white" aria-label="Log out"><LogOut size={14} /></button></div></div>
    </aside>
    {open && <button onClick={() => setOpen(false)} aria-label="Close menu" className="fixed inset-0 z-40 bg-[#122f49]/50 md:hidden" />}
    <div className="md:pl-[245px]"><header className="sticky top-0 z-30 flex h-[70px] items-center justify-between border-b border-[#e1e7eb] bg-[#f5f7f8]/90 px-5 backdrop-blur-xl lg:px-8"><button onClick={() => setOpen(true)} className="rounded-xl p-2 text-[#29475b] md:hidden" aria-label="Open navigation"><Menu size={20} /></button><div className="hidden items-center gap-2 text-sm font-semibold text-[#7c8c95] md:flex"><Command size={17} /> Parkwise operations <span className="ml-1 rounded-md bg-[#e3eef1] px-2 py-1 text-[10px] text-[#527482]">DEMO DATA</span></div><div className="ml-auto flex items-center gap-3"><button className="rounded-xl p-2 text-[#71818b] hover:bg-white" aria-label="Help"><CircleHelp size={18} /></button><Link href="/notifications" className="rounded-xl p-2 text-[#71818b] hover:bg-white" aria-label="Notifications"><Bell size={18} /></Link><span className="h-7 w-px bg-[#dfe6ea]" /><span className="text-xs font-bold text-[#344e5f]">{user?.name || 'Admin'}</span><span className="grid h-8 w-8 place-items-center rounded-full bg-[#d8e8ed] text-xs font-bold text-[#1d5b72]">{(user?.name || 'Admin').split(' ').map((n) => n[0]).join('').slice(0, 2)}</span></div></header><main className="mx-auto max-w-[1400px] px-5 py-7 lg:px-8">{children}</main></div>
  </div>;
}

export function PageHeader({ eyebrow, title, detail, action }: { eyebrow?: string; title: string; detail?: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div>{eyebrow && <p className="mb-2 text-[11px] font-bold uppercase tracking-[.16em] text-[#c28636]">{eyebrow}</p>}<h1 className="font-display text-[28px] font-bold tracking-[-.04em] text-[#183653] md:text-[34px]">{title}</h1>{detail && <p className="mt-1.5 text-sm text-[#788994]">{detail}</p>}</div>{action}</div>;
}

export function StatCard({ label, value, delta, icon: Icon, tone = 'navy' }: { label: string; value: string; delta?: string; icon: typeof Gauge; tone?: 'navy' | 'teal' | 'gold' | 'green' }) {
  const tones = { navy: 'bg-[#e8eef4] text-[#1d506c]', teal: 'bg-[#dff2ef] text-[#247d78]', gold: 'bg-[#fff0d6] text-[#9a6c28]', green: 'bg-[#e3f3e9] text-[#24744b]' };
  return <div className="rounded-2xl border border-[#dfe7eb] bg-white p-4 shadow-[0_7px_20px_rgba(44,67,87,.04)]"><div className="flex items-start justify-between"><span className={`grid h-9 w-9 place-items-center rounded-xl ${tones[tone]}`}><Icon size={17} /></span>{delta && <span className="rounded-full bg-[#e3f3e9] px-2 py-1 text-[10px] font-bold text-[#287952]">{delta}</span>}</div><p className="mt-4 text-[12px] font-semibold text-[#7a8a94]">{label}</p><p className="mt-0.5 font-display text-[26px] font-bold tracking-[-.05em] text-[#183653]">{value}</p></div>;
}

export function MockMap({ locations = parkingLocations, compact = false }: { locations?: ParkingLocation[]; compact?: boolean }) {
  return <div data-testid="mock-map" className={`relative isolate overflow-hidden rounded-2xl border border-[#cfdde2] bg-[#dce9e7] ${compact ? 'h-[220px]' : 'h-[480px]'}`}>
    <div className="absolute inset-0 opacity-50" style={{ backgroundImage: 'linear-gradient(30deg, transparent 46%, #b5ceca 47%, #b5ceca 49%, transparent 50%), linear-gradient(145deg, transparent 42%, #b5ceca 43%, #b5ceca 45%, transparent 46%)', backgroundSize: '110px 90px' }} />
    <div className="absolute -left-10 top-20 h-20 w-[120%] rotate-[12deg] border-y-8 border-white/70 bg-[#c3d6d0]/40" />
    <div className="absolute left-1/4 top-0 h-[130%] w-9 rotate-[37deg] bg-white/70" />
    <div className="absolute bottom-0 right-1/4 h-[130%] w-5 -rotate-[28deg] bg-white/60" />
    <div className="absolute left-5 top-5 rounded-lg bg-white/85 px-2.5 py-1.5 text-[10px] font-bold text-[#55717b] shadow-sm"><span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-[#ddab50]" /> MOCK MAP · LIVE DATA PREVIEW</div>
    {locations.slice(0, 5).map((location, index) => <Link key={location.id} href={`/parking/${location.id}`} data-testid={`map-pin-${location.id}`} className="absolute transition-transform hover:scale-110" style={{ left: `${18 + (index * 17) % 68}%`, top: `${30 + (index * 23) % 52}%` }}><span className="relative grid h-9 w-9 place-items-center rounded-full border-4 border-white bg-[#173f5c] text-white shadow-lg"><MapPin size={16} fill="currentColor" /><span className="absolute -bottom-1 h-1.5 w-1.5 rotate-45 bg-[#173f5c]" /></span><span className="absolute left-1/2 top-10 hidden -translate-x-1/2 whitespace-nowrap rounded bg-[#173f5c] px-2 py-1 text-[10px] font-bold text-white group-hover:block">{location.name}</span></Link>)}
    {!compact && <div className="absolute bottom-4 left-4 rounded-xl bg-white/90 p-3 text-[11px] shadow-sm"><p className="font-bold text-[#345064]">5 locations in view</p><p className="mt-0.5 text-[#81909a]">Map tiles are a preview until maps connect.</p></div>}
  </div>;
}

export function ParkingCard({ location }: { location: ParkingLocation }) {
  return <article data-testid={`card-parking-${location.id}`} className="group rounded-2xl border border-[#dfe7eb] bg-white p-3 shadow-[0_7px_20px_rgba(44,67,87,.04)] transition-all hover:-translate-y-0.5 hover:shadow-[0_16px_28px_rgba(44,67,87,.1)]"><div className={`relative flex h-28 items-end overflow-hidden rounded-xl bg-gradient-to-br ${location.accent} p-3`}><div className="absolute inset-0 opacity-25 grid-fade" /><div className="relative flex w-full items-end justify-between"><div><p className="text-[10px] font-semibold text-white/70">{location.zone} zone · {location.distance}</p><h3 className="mt-0.5 font-display text-[17px] font-bold text-white">{location.name}</h3></div><span className="rounded-lg bg-white/15 px-2 py-1 text-[11px] font-bold text-white backdrop-blur-sm"><Star size={11} className="mr-1 inline fill-[#f7c36f] text-[#f7c36f]" />{location.rating}</span></div></div><div className="px-1 pt-3"><div className="flex items-center justify-between gap-2"><p className="flex min-w-0 items-center gap-1.5 truncate text-xs text-[#71818b]"><MapPin size={13} className="shrink-0 text-[#8cabb3]" />{location.address}</p><span className="shrink-0 text-xs font-bold text-[#183653]">₹{location.pricePerHour}/hr</span></div><div className="mt-3 flex items-center justify-between"><span className="text-xs font-bold text-[#27754d]"><span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-current" />{location.availableSlots} spots open</span><span className="text-[11px] text-[#91a0a8]">{location.totalSlots} total</span></div><div className="mt-3 flex flex-wrap gap-1.5">{location.facilities.slice(0, 3).map((facility) => <span key={facility} className="rounded-md bg-[#f0f4f5] px-2 py-1 text-[10px] font-semibold text-[#687b86]">{facility}</span>)}</div><Link href={`/parking/${location.id}`} data-testid={`link-view-parking-${location.id}`} className="mt-3 flex items-center justify-between rounded-xl border border-[#dfe7eb] px-3 py-2.5 text-xs font-bold text-[#28566e] transition-colors hover:border-[#9dbcc6] hover:bg-[#f1f7f7]">View location <ArrowRight size={14} /></Link></div></article>;
}

const statusMeta: Record<SlotStatus, { label: string; className: string }> = {
  available: { label: 'Available', className: 'border-[#8bc7ab] bg-[#e5f5eb] text-[#27784f] hover:bg-[#cfeede]' },
  occupied: { label: 'Occupied', className: 'border-[#edb0ab] bg-[#fcedec] text-[#ad514b]' },
  reserved: { label: 'Reserved', className: 'border-[#b3b5e5] bg-[#e9eafa] text-[#5657a1]' },
  maintenance: { label: 'Service', className: 'border-[#e8c98d] bg-[#fff3dd] text-[#96691f]' },
};

export function SlotMap({ slots, selected, onSelect }: { slots: ParkingSlot[]; selected?: string; onSelect?: (slot: ParkingSlot) => void }) {
  return <div data-testid="parking-slot-map" className="overflow-x-auto rounded-2xl border border-[#dfe7eb] bg-[#f2f5f5] p-4 sm:p-6"><div className="mx-auto mb-5 max-w-[420px] rounded-lg border border-dashed border-[#9fbab9] bg-[#e1efed] py-2 text-center text-[10px] font-bold uppercase tracking-[.18em] text-[#56837e]">Entry / exit</div><div className="mx-auto grid min-w-[350px] max-w-[560px] grid-cols-6 gap-2 sm:gap-3">{slots.map((slot) => { const meta = statusMeta[slot.status]; const isSelected = selected === slot.id; const canSelect = slot.status === 'available'; return <button key={slot.id} disabled={!canSelect} onClick={() => onSelect?.(slot)} data-testid={`slot-${slot.id}`} aria-label={`${slot.label}, ${meta.label}`} className={`relative flex aspect-[.65] min-h-16 flex-col items-center justify-center rounded-xl border-2 text-[11px] font-bold transition-all ${isSelected ? 'border-[#e2a849] bg-[#fff0cc] text-[#805619] shadow-[0_0_0_3px_rgba(226,168,73,.18)]' : meta.className} ${canSelect ? 'cursor-pointer hover:-translate-y-0.5' : 'cursor-not-allowed opacity-80'}`}><Car size={16} className="mb-1 opacity-70" /><span>{slot.label}</span>{isSelected && <span className="absolute -right-1.5 -top-1.5 grid h-4 w-4 place-items-center rounded-full bg-[#e2a849] text-white"><Check size={10} /></span>}</button>; })}</div><div className="mt-6 flex flex-wrap justify-center gap-x-5 gap-y-2 border-t border-[#dfe7eb] pt-4 text-[10px] font-semibold text-[#71818b]">{Object.entries(statusMeta).map(([key, value]) => <span key={key} className="flex items-center gap-1.5"><span className={`h-2.5 w-2.5 rounded-sm border ${value.className}`} />{value.label}</span>)}</div></div>;
}

export function BookingCard({ booking, onCancel }: { booking: Booking; onCancel?: (id: string) => void }) {
  const isCancellable = (booking.status === 'upcoming' || booking.status === 'confirmed') && onCancel;
  const displayTime = booking.startTime && booking.endTime ? `${booking.startTime} - ${booking.endTime}` : (booking.time || '12:00 PM');
  return <article data-testid={`card-booking-${booking.id}`} className="rounded-2xl border border-[#dfe7eb] bg-white p-4 shadow-[0_7px_20px_rgba(44,67,87,.04)]"><div className="flex items-start justify-between gap-3"><div><p className="text-[10px] font-bold uppercase tracking-[.12em] text-[#c28636]">{booking.id}</p><h3 className="mt-1 font-display text-[18px] font-bold text-[#183653]">{booking.locationName}</h3><p className="mt-1 flex items-center gap-1.5 text-xs text-[#71818b]"><MapPin size={13} />Slot {booking.slotNumber || booking.slot} · {booking.date}</p></div><StatusBadge status={booking.status} /></div><div className="my-4 grid grid-cols-3 gap-2 rounded-xl bg-[#f4f7f7] p-3"><div><p className="text-[10px] text-[#82919a]">Time</p><p className="mt-1 truncate text-xs font-bold text-[#345064]">{displayTime}</p></div><div><p className="text-[10px] text-[#82919a]">Duration</p><p className="mt-1 text-xs font-bold text-[#345064]">{booking.duration} hour{booking.duration > 1 ? 's' : ''}</p></div><div><p className="text-[10px] text-[#82919a]">Amount</p><p className="mt-1 text-xs font-bold text-[#345064]">₹{booking.amount}</p></div></div><div className="flex gap-2"><Link href={`/bookings/${booking.id}`} data-testid={`link-booking-${booking.id}`} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-[#153b5b] px-3 py-2.5 text-xs font-bold text-white hover:bg-[#214d6d]">View booking <ChevronRight size={13} /></Link>{isCancellable && <button onClick={() => onCancel(booking.id)} data-testid={`button-cancel-${booking.id}`} className="rounded-xl border border-[#f1ceca] px-3 text-xs font-bold text-[#b2534e] hover:bg-[#fdf1f0]">Cancel</button>}</div></article>;
}

export function QRCard({ bookingId }: { bookingId: string }) {
  return <div data-testid="mock-qr" className="rounded-2xl border border-[#dfe7eb] bg-[#fbfcfc] p-4 text-center"><div className="mx-auto grid w-[126px] grid-cols-8 gap-1 rounded-lg border-4 border-[#153b5b] bg-white p-2">{Array.from({ length: 64 }, (_, i) => <span key={i} className={`aspect-square rounded-[1px] ${[0,1,2,5,7,8,10,12,14,15,16,18,21,23,24,25,28,30,31,33,35,36,37,40,42,43,45,47,48,50,51,53,54,57,58,60,62,63].includes(i) ? 'bg-[#153b5b]' : 'bg-transparent'}`} />)}</div><p className="mt-3 text-[10px] font-bold uppercase tracking-[.15em] text-[#80909a]">Demo access pass</p><p className="mt-1 font-mono text-xs font-bold text-[#345064]">{bookingId}</p><p className="mt-2 text-[10px] text-[#9aa6ac]">QR validation is mocked for this preview.</p></div>;
}

export function EmptyState({ icon: Icon = Compass, title, detail, action }: { icon?: typeof Compass; title: string; detail: string; action?: ReactNode }) {
  return <div className="rounded-2xl border border-dashed border-[#ccdce1] bg-[#f7faf9] px-6 py-16 text-center"><span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-[#e4f0ef] text-[#4b8b87]"><Icon size={22} /></span><h3 className="mt-4 font-display text-lg font-bold text-[#29485c]">{title}</h3><p className="mx-auto mt-1 max-w-sm text-sm leading-6 text-[#7f8e96]">{detail}</p>{action && <div className="mt-5">{action}</div>}</div>;
}

export function FilterButton({ children, active, onClick }: { children: ReactNode; active?: boolean; onClick?: () => void }) {
  return <button onClick={onClick} data-testid="button-filter" className={`flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-bold transition-colors ${active ? 'border-[#98bcc3] bg-[#e6f2f1] text-[#286a70]' : 'border-[#dfe7eb] bg-white text-[#71818b] hover:bg-[#f2f7f7]'}`}><SlidersHorizontal size={14} />{children}</button>;
}

export const uiIcons = { ArrowRight, Bell, Building2, CalendarDays, Car, Clock3, CreditCard, History, MapPin, Navigation, Search, ShieldCheck, Sparkles, Star, UserRound, Zap };