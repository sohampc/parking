import { ErrorBoundary } from '@/components/error-boundary';
import ParkingHero3D, { ParkingHero3DFallback } from '@/components/three/ParkingHero3D';

export default function ParkingHero3DBoundary() {
  return (
    <ErrorBoundary FallbackComponent={ParkingHero3DFallback}>
      <ParkingHero3D />
    </ErrorBoundary>
  );
}
