import { Suspense, useMemo, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { ContactShadows, Float, Grid, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

/**
 * A small stylised "toy car" built entirely from primitive geometry
 * (boxes + cylinders + spheres). No .glb/.gltf models or textures are
 * loaded, so this renders instantly and works fully offline.
 */
function ToyCar() {
  const group = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!group.current) return;
    const t = state.clock.getElapsedTime();
    group.current.rotation.y = t * 0.35;
    group.current.position.y = 0.05 + Math.sin(t * 1.4) * 0.06;
  });

  const wheelPositions: [number, number, number][] = [
    [0.72, -0.18, 0.52],
    [-0.72, -0.18, 0.52],
    [0.72, -0.18, -0.52],
    [-0.72, -0.18, -0.52],
  ];

  return (
    <group ref={group} position={[0, 0.05, 0]} castShadow>
      {/* body */}
      <mesh position={[0, 0.05, 0]} castShadow receiveShadow>
        <boxGeometry args={[2.15, 0.5, 1.05]} />
        <meshStandardMaterial color="#f4c26f" roughness={0.35} metalness={0.15} />
      </mesh>
      {/* cabin */}
      <mesh position={[-0.12, 0.46, 0]} castShadow>
        <boxGeometry args={[1.15, 0.42, 0.92]} />
        <meshStandardMaterial color="#173f5d" roughness={0.15} metalness={0.35} />
      </mesh>
      {/* front bumper accent */}
      <mesh position={[1.08, -0.02, 0]} castShadow>
        <boxGeometry args={[0.06, 0.28, 0.98]} />
        <meshStandardMaterial color="#2f7c75" roughness={0.3} />
      </mesh>
      {/* headlights */}
      {[0.36, -0.36].map((z) => (
        <mesh key={z} position={[1.06, 0.05, z]}>
          <sphereGeometry args={[0.08, 16, 16]} />
          <meshStandardMaterial color="#fff6e0" emissive="#ffe6a3" emissiveIntensity={1.4} />
        </mesh>
      ))}
      {/* wheels */}
      {wheelPositions.map((pos, i) => (
        <mesh key={i} position={pos} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[0.26, 0.26, 0.22, 24]} />
          <meshStandardMaterial color="#1c2a2e" roughness={0.9} />
        </mesh>
      ))}
    </group>
  );
}

/** A slim glowing "P" marker pin, built from a cone + ring — no font/text asset needed. */
function ParkingPin({ position, color }: { position: [number, number, number]; color: string }) {
  return (
    <Float speed={2.2} rotationIntensity={0.15} floatIntensity={0.9}>
      <group position={position}>
        <mesh rotation={[Math.PI, 0, 0]} castShadow>
          <coneGeometry args={[0.16, 0.32, 24]} />
          <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
        </mesh>
        <mesh position={[0, 0.24, 0]}>
          <sphereGeometry args={[0.17, 24, 24]} />
          <meshStandardMaterial color={color} roughness={0.25} metalness={0.25} />
        </mesh>
        <mesh position={[0, 0.24, 0]}>
          <ringGeometry args={[0.06, 0.09, 24]} />
          <meshBasicMaterial color="#173f5d" side={THREE.DoubleSide} />
        </mesh>
      </group>
    </Float>
  );
}

function Scene() {
  const pins = useMemo(
    () =>
      [
        { position: [-1.9, 0.5, 1.1] as [number, number, number], color: '#f4c26f' },
        { position: [1.95, 0.75, -1.0] as [number, number, number], color: '#2f7c75' },
        { position: [0.2, 0.95, 1.9] as [number, number, number], color: '#f4c26f' },
      ],
    [],
  );

  return (
    <>
      <ambientLight intensity={0.65} />
      <directionalLight position={[3, 5, 2]} intensity={1.3} castShadow shadow-mapSize={[1024, 1024]} />
      <pointLight position={[-3, 2, -2]} intensity={0.5} color="#82c4be" />

      <ToyCar />

      {pins.map((pin, i) => (
        <ParkingPin key={i} {...pin} />
      ))}

      <Grid
        position={[0, -0.42, 0]}
        args={[10, 10]}
        cellSize={0.5}
        cellThickness={0.5}
        cellColor="#3a5f66"
        sectionSize={2}
        sectionThickness={1}
        sectionColor="#82c4be"
        fadeDistance={9}
        fadeStrength={1.4}
        infiniteGrid
      />

      <ContactShadows position={[0, -0.41, 0]} opacity={0.55} scale={8} blur={2.2} far={2.5} color="#0b1f2c" />

      <OrbitControls
        enableZoom={false}
        enablePan={false}
        autoRotate
        autoRotateSpeed={0.6}
        minPolarAngle={Math.PI / 2.9}
        maxPolarAngle={Math.PI / 2.15}
      />
    </>
  );
}

/**
 * Static, animation-free gradient shown if WebGL isn't available or the scene
 * errors out. Accepts (and ignores) the ErrorBoundary's fallback props so it
 * can be passed straight to <ErrorBoundary FallbackComponent={...} />.
 */
export function ParkingHero3DFallback(_props: { error?: Error; resetError?: () => void }) {
  return (
    <div className="grid h-full w-full place-items-center bg-gradient-to-br from-[#173f5d] via-[#1f4d4e] to-[#2f7c75]">
      <div className="h-20 w-20 rotate-6 rounded-2xl border-4 border-white/30 bg-white/10" />
    </div>
  );
}

export default function ParkingHero3D() {
  return (
    <Canvas
      shadows
      dpr={[1, 1.75]}
      camera={{ position: [3.4, 2.4, 4.2], fov: 38 }}
      gl={{ antialias: true, alpha: true }}
      style={{ background: 'transparent' }}
    >
      <Suspense fallback={null}>
        <Scene />
      </Suspense>
    </Canvas>
  );
}
