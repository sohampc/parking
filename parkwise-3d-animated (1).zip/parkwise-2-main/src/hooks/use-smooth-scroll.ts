import { useEffect } from 'react';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

let activeLenis: Lenis | null = null;

/** The current Lenis instance, if smooth scrolling is active. Useful for one-off `scrollTo` calls. */
export function getLenis() {
  return activeLenis;
}

/**
 * Mounts Lenis smooth scrolling for as long as the calling component is
 * mounted, and drives it from GSAP's ticker so ScrollTrigger-based
 * animations stay perfectly in sync with the smoothed scroll position.
 *
 * Respects `prefers-reduced-motion` by skipping smoothing entirely.
 */
export function useSmoothScroll(enabled = true) {
  useEffect(() => {
    if (!enabled) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const lenis = new Lenis({
      duration: 1.1,
      easing: (t: number) => 1 - Math.pow(1 - t, 3),
      smoothWheel: true,
    });
    activeLenis = lenis;

    lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000);
    });
    gsap.ticker.lagSmoothing(0);

    return () => {
      lenis.destroy();
      activeLenis = null;
      gsap.ticker.remove((time) => {
        lenis.raf(time * 1000);
      });
    };
  }, [enabled]);
}
